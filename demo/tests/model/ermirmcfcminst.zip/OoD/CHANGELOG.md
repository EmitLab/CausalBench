# Changelog

All notable changes to this project will be documented in this file.

### Version history
## 3/12/2020: v0 launched
