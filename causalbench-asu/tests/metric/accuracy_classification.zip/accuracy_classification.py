from typing import Any, Optional, Sequence

from sklearn.metrics import accuracy_score
from causalbench.formats import SpatioTemporalData


def evaluate(
    prediction: SpatioTemporalData,
    ground_truth: SpatioTemporalData,
    helpers: Any,
    # sklearn.metrics.accuracy_score hyperparameters
    normalize: bool,
    sample_weight: Optional[Sequence[float]],
):
    y_true = helpers.get_target(ground_truth)
    y_pred = helpers.get_target(prediction)

    return {"score": accuracy_score(y_true, y_pred, normalize=normalize, sample_weight=sample_weight)}
