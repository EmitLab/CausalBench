from typing import Any, Optional, Sequence, Union

import numpy as np
from sklearn.metrics import precision_score

from causalbench.formats import SpatioTemporalData


def evaluate(
    prediction: SpatioTemporalData,
    ground_truth: SpatioTemporalData,
    helpers: Any,
    
    # sklearn.metrics.precision_score Hyperparameters
    labels: Optional[Sequence[Union[int, str]]] = None,
    pos_label: Union[int, str] = 1,
    average: Optional[str] = "macro",
    sample_weight: Optional[Sequence[float]] = None,
    zero_division: Union[int, float, str] = 0,
):
    y_true = helpers.get_target(ground_truth)
    y_pred = helpers.get_target(prediction)

    score = precision_score(
        y_true,
        y_pred,
        labels=labels,
        pos_label=pos_label,
        average=average,
        sample_weight=sample_weight,
        zero_division=zero_division,
    )
    
    return {"score": score}
