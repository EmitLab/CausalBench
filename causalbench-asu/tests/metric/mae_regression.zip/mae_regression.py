from typing import Any, Optional, Sequence, Union

from sklearn.metrics import mean_absolute_error
from causalbench.formats import SpatioTemporalData


def evaluate(
    prediction: SpatioTemporalData,
    ground_truth: SpatioTemporalData,
    helpers: Any,
    # sklearn.metrics.mean_absolute_error hyperparams
    sample_weight: Optional[Sequence[float]] = None,
    multioutput: Union[str, Sequence[float]] = "uniform_average",
):
    y_true = helpers.get_target(ground_truth)
    y_pred = helpers.get_target(prediction)

    return {"score": mean_absolute_error(y_true, y_pred, sample_weight=sample_weight, multioutput=multioutput)}
